const Discord = require("discord.js");
const client = new Discord.Client();
const fs = require("fs");
const express = require("express");
const db = require("quick.db"); 
const app = express(); 
module.exports = {
run(client,message,args) {

const prefix = client.prefix;

if(message.author.bot || !message.guild)return;
let embed = new Discord.MessageEmbed()
.setTitle(`Help Menu`) // By Ahmed Abd El-Latif Gaming - Sekai
.setAuthor(`${message.author.tag}`,message.author.avatarURL())
.setColor(`RANDOM`)
.setThumbnail(client.user.avatarURL())
.setTimestamp()
.addField(`**● |MY PREFIX==> ${prefix}**`)
.addField(`**● | ${prefix}help - ${prefix}h**`,`**\` قائمة الهيلب \`**`)

.addField(`**● | ${prefix}line - خط**`, `**\` لوضع الخط \`**`)
.addField(`**● | ${prefix}add-room \n● | ${prefix}ar**`, `**\` لاضافة روم الي الخط التلقائي \`**`)
.addField(`**● | ${prefix}clear-db \n● | ${prefix}cd**`,`**\` لمسح جميع البيانات الخاصة بالسيرفر \`**`)
.addField(`**● | ${prefix}set-line \n● | ${prefix}sl**`,`**\` لتحديد الخط \`**`)
.addField(`**● | ${prefix}set-reaction \n● | ${prefix}sr**`,`**\` لتحديد الريأكشن \`**`)

.addField(`**● | ${prefix}support \n● | ${prefix}sup**`, `**\` الدعم الفني للبوت \`**`)
.setFooter(`This Bot Made By POWER DZ#0303 <@447768651643486208>`);
message.channel.send(embed)


    },
    config : {
        name: "help",
        alis : ["h" , "hlep" , "power"]
    }
}
